GuildSyncApplications 1.4.3 - standalone ESO add-on

1. Close ESO. Extract the GuildSyncApplications folder into:
   Documents/Elder Scrolls Online/live/AddOns/
   The result should be AddOns/GuildSyncApplications/GuildSyncApplications.txt.
2. Install LibAddonMenu-2.0 separately (for example, using Minion).
3. Start ESO and enable GuildSyncApplications and its dependency in Add-Ons.
   No GuildSync desktop client, backend server or Discord bot is required.
4. The add-on creates its saved settings after you log in and log out.
   To edit those settings, use the Welcome Studio and download its Lua file.
   With ESO closed, back up and replace:
   Documents/Elder Scrolls Online/live/SavedVariables/GuildSyncApplications.lua
   The downloaded settings file belongs in SavedVariables, not AddOns.

This ZIP contains add-on software only, with no player accounts or records.
For an existing installation, do not delete or replace your SavedVariables
when updating the add-on folder. Use /gsa settings for in-game settings.

Original author: @evainefaye
Source: https://github.com/skperdue68/GuildSync/tree/master/ESO/GuildSyncApplications
Bundled version: 1.4.3. LibAddonMenu-2.0 is not included.
